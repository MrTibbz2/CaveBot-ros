from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module_ipa_interface.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module_name = resolve('module_name')
    l_0_has_map = resolve('has_map')
    l_0_has_string = resolve('has_string')
    l_0_has_array = resolve('has_array')
    l_0_has_namespace = resolve('has_namespace')
    l_0_namespace = resolve('namespace')
    l_0_consts = resolve('consts')
    l_0_cmd_enum_name = resolve('cmd_enum_name')
    l_0_interface_main = resolve('interface_main')
    l_0_cmd_event_enum_name = resolve('cmd_event_enum_name')
    l_0_interface_event = resolve('interface_event')
    l_0_enums = resolve('enums')
    l_0_structs_nonempty = resolve('structs_nonempty')
    l_0_interface_name = resolve('interface_name')
    l_0_funcs = missing
    try:
        t_1 = environment.filters['cap']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cap' found.")
    try:
        t_2 = environment.filters['is_enum']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum' found.")
    try:
        t_3 = environment.filters['is_pod']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_pod' found.")
    try:
        t_4 = environment.filters['method_parameters']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'method_parameters' found.")
    try:
        t_5 = environment.filters['method_return_value']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'method_return_value' found.")
    try:
        t_6 = environment.filters['name']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'name' found.")
    try:
        t_7 = environment.filters['reverse']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'reverse' found.")
    pass
    l_0_funcs = context.vars['funcs'] = environment.get_template('definition_functions.tmpl', 'module_ipa_interface.h.tmpl')._get_default_module(context)
    context.exported_vars.discard('funcs')
    yield '/* SPDX-License-Identifier: LGPL-2.1-or-later */\n/*\n * Copyright (C) 2020, Google Inc.\n *\n * Image Processing Algorithm interface for '
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '\n *\n * This file is auto-generated. Do not edit.\n */\n\n#pragma once\n\n'
    if (undefined(name='has_map') if l_0_has_map is missing else l_0_has_map):
        pass
        yield '#include <map>'
    yield '\n'
    if (undefined(name='has_string') if l_0_has_string is missing else l_0_has_string):
        pass
        yield '#include <string>'
    yield '\n'
    if (undefined(name='has_array') if l_0_has_array is missing else l_0_has_array):
        pass
        yield '#include <vector>'
    yield '\n\n#include <libcamera/base/flags.h>\n#include <libcamera/base/signal.h>\n\n#include <libcamera/controls.h>\n#include <libcamera/framebuffer.h>\n#include <libcamera/geometry.h>\n\n#include <libcamera/ipa/core_ipa_interface.h>\n#include <libcamera/ipa/ipa_interface.h>\n\nnamespace libcamera {'
    if (undefined(name='has_namespace') if l_0_has_namespace is missing else l_0_has_namespace):
        pass
        yield '\n'
        for l_1_ns in (undefined(name='namespace') if l_0_namespace is missing else l_0_namespace):
            _loop_vars = {}
            pass
            yield '\nnamespace '
            yield str(l_1_ns)
            yield ' {\n'
        l_1_ns = missing
    yield '\n\n'
    for l_1_const in (undefined(name='consts') if l_0_consts is missing else l_0_consts):
        _loop_vars = {}
        pass
        yield '\nconst '
        yield str(t_6(environment.getattr(l_1_const, 'kind')))
        yield ' '
        yield str(environment.getattr(l_1_const, 'mojom_name'))
        yield ' = '
        yield str(environment.getattr(l_1_const, 'value'))
        yield ';\n'
    l_1_const = missing
    yield '\n\nenum class '
    yield str((undefined(name='cmd_enum_name') if l_0_cmd_enum_name is missing else l_0_cmd_enum_name))
    yield ' {\n\tExit = 0,'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface_main') if l_0_interface_main is missing else l_0_interface_main), 'methods'), undefined):
        _loop_vars = {}
        pass
        yield '\n\t'
        yield str(t_1(environment.getattr(l_1_method, 'mojom_name')))
        yield ' = '
        yield str(environment.getattr(l_1_loop, 'index'))
        yield ','
    l_1_loop = l_1_method = missing
    yield '\n};\n\nenum class '
    yield str((undefined(name='cmd_event_enum_name') if l_0_cmd_event_enum_name is missing else l_0_cmd_event_enum_name))
    yield ' {'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface_event') if l_0_interface_event is missing else l_0_interface_event), 'methods'), undefined):
        _loop_vars = {}
        pass
        yield '\n\t'
        yield str(t_1(environment.getattr(l_1_method, 'mojom_name')))
        yield ' = '
        yield str(environment.getattr(l_1_loop, 'index'))
        yield ','
    l_1_loop = l_1_method = missing
    yield '\n};\n\n'
    for l_1_enum in (undefined(name='enums') if l_0_enums is missing else l_0_enums):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call(environment.getattr((undefined(name='funcs') if l_0_funcs is missing else l_0_funcs), 'define_enum'), l_1_enum, _loop_vars=_loop_vars))
        yield '\n'
    l_1_enum = missing
    for l_1_struct in (undefined(name='structs_nonempty') if l_0_structs_nonempty is missing else l_0_structs_nonempty):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call(environment.getattr((undefined(name='funcs') if l_0_funcs is missing else l_0_funcs), 'define_struct'), l_1_struct, _loop_vars=_loop_vars))
        yield '\n'
    l_1_struct = missing
    yield '\nclass '
    yield str((undefined(name='interface_name') if l_0_interface_name is missing else l_0_interface_name))
    yield ' : public IPAInterface\n{\npublic:\n'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface_main') if l_0_interface_main is missing else l_0_interface_main), 'methods'), undefined):
        _loop_vars = {}
        pass
        yield '\n\tvirtual '
        yield str(t_5(l_1_method))
        yield ' '
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield '('
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(t_4(l_1_method), undefined):
            _loop_vars = {}
            pass
            yield '\n\t\t'
            yield str(l_2_param)
            yield str((',' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 72 in 'module_ipa_interface.h.tmpl' evaluated to false and no else section was defined.")))
        l_2_loop = l_2_param = missing
        yield ') = 0;\n'
    l_1_loop = l_1_method = missing
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface_event') if l_0_interface_event is missing else l_0_interface_event), 'methods'), undefined):
        _loop_vars = {}
        pass
        yield '\n\tSignal<'
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            _loop_vars = {}
            pass
            yield str(('const ' if (not t_3(l_2_param)) else cond_expr_undefined("the inline if-expression on line 80 in 'module_ipa_interface.h.tmpl' evaluated to false and no else section was defined.")))
            yield str(t_6(l_2_param))
            yield str((' &' if ((not t_3(l_2_param)) and (not t_2(l_2_param))) else cond_expr_undefined("the inline if-expression on line 80 in 'module_ipa_interface.h.tmpl' evaluated to false and no else section was defined.")))
            yield str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 81 in 'module_ipa_interface.h.tmpl' evaluated to false and no else section was defined.")))
        l_2_loop = l_2_param = missing
        yield '> '
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield ';\n'
    l_1_loop = l_1_method = missing
    yield '};'
    if (undefined(name='has_namespace') if l_0_has_namespace is missing else l_0_has_namespace):
        pass
        yield '\n'
        for l_1_ns in t_7((undefined(name='namespace') if l_0_namespace is missing else l_0_namespace)):
            _loop_vars = {}
            pass
            yield '\n} /* namespace '
            yield str(l_1_ns)
            yield ' */\n'
        l_1_ns = missing
    yield '\n} /* namespace libcamera */'

blocks = {}
debug_info = '5=68&10=71&17=73&18=77&19=81&32=85&33=88&34=92&38=96&39=100&42=108&44=111&45=115&49=121&50=124&51=128&55=134&56=138&59=141&60=145&66=149&69=152&70=156&71=161&72=165&77=171&79=176&80=179&81=182&83=185&87=189&88=192&89=196'