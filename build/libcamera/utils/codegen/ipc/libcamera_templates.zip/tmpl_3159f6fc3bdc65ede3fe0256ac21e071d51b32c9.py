from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'serializer.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_check_data_size = l_0_serializer_field = l_0_deserializer_field = l_0_serializer = l_0_deserializer_fd = l_0_deserializer_fd_simple = l_0_deserializer_no_fd = l_0_deserializer = missing
    try:
        t_1 = environment.filters['bit_width']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'bit_width' found.")
    try:
        t_2 = environment.filters['has_fd']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'has_fd' found.")
    try:
        t_3 = environment.filters['int']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'int' found.")
    try:
        t_4 = environment.filters['is_array']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_array' found.")
    try:
        t_5 = environment.filters['is_controls']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_controls' found.")
    try:
        t_6 = environment.filters['is_enum']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum' found.")
    try:
        t_7 = environment.filters['is_enum_scoped']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_scoped' found.")
    try:
        t_8 = environment.filters['is_fd']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'is_fd' found.")
    try:
        t_9 = environment.filters['is_flags']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_flags' found.")
    try:
        t_10 = environment.filters['is_map']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'is_map' found.")
    try:
        t_11 = environment.filters['is_plain_struct']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'is_plain_struct' found.")
    try:
        t_12 = environment.filters['is_pod']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'is_pod' found.")
    try:
        t_13 = environment.filters['is_str']
    except KeyError:
        @internalcode
        def t_13(*unused):
            raise TemplateRuntimeError("No filter named 'is_str' found.")
    try:
        t_14 = environment.filters['name']
    except KeyError:
        @internalcode
        def t_14(*unused):
            raise TemplateRuntimeError("No filter named 'name' found.")
    try:
        t_15 = environment.filters['name_full']
    except KeyError:
        @internalcode
        def t_15(*unused):
            raise TemplateRuntimeError("No filter named 'name_full' found.")
    try:
        t_16 = environment.filters['needs_control_serializer']
    except KeyError:
        @internalcode
        def t_16(*unused):
            raise TemplateRuntimeError("No filter named 'needs_control_serializer' found.")
    pass
    def macro(l_1_size, l_1_dataSize, l_1_name, l_1_typename):
        t_17 = []
        if l_1_size is missing:
            l_1_size = undefined("parameter 'size' was not provided", name='size')
        if l_1_dataSize is missing:
            l_1_dataSize = undefined("parameter 'dataSize' was not provided", name='dataSize')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        if l_1_typename is missing:
            l_1_typename = undefined("parameter 'typename' was not provided", name='typename')
        pass
        t_17.extend((
            '\n\t\tif (',
            str(l_1_dataSize),
            ' < ',
            str(l_1_size),
            ') {\n\t\t\tLOG(IPADataSerializer, Error)\n\t\t\t\t<< "Failed to deserialize " << "',
            str(l_1_name),
            '"\n\t\t\t\t<< ": not enough ',
            str(l_1_typename),
            ', expected "\n\t\t\t\t<< (',
            str(l_1_size),
            ') << ", got " << (',
            str(l_1_dataSize),
            ');\n\t\t\treturn ret;\n\t\t}',
        ))
        return concat(t_17)
    context.exported_vars.add('check_data_size')
    context.vars['check_data_size'] = l_0_check_data_size = Macro(environment, macro, 'check_data_size', ('size', 'dataSize', 'name', 'typename'), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n\n'
    def macro(l_1_field, l_1_loop):
        t_18 = []
        if l_1_field is missing:
            l_1_field = undefined("parameter 'field' was not provided", name='field')
        if l_1_loop is missing:
            l_1_loop = undefined("parameter 'loop' was not provided", name='loop')
        pass
        if (t_12(l_1_field) or t_6(l_1_field)):
            pass
            t_18.extend((
                '\n\t\tstd::vector<uint8_t> ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                ';\n\t\tstd::tie(',
                str(environment.getattr(l_1_field, 'mojom_name')),
                ', std::ignore) =',
            ))
            if t_12(l_1_field):
                pass
                t_18.extend((
                    '\n\t\t\tIPADataSerializer<',
                    str(t_14(l_1_field)),
                    '>::serialize(data.',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    ');',
                ))
            elif t_9(l_1_field):
                pass
                t_18.extend((
                    '\n\t\t\tIPADataSerializer<',
                    str(t_15(l_1_field)),
                    '>::serialize(data.',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    ');',
                ))
            elif t_7(l_1_field):
                pass
                t_18.extend((
                    '\n\t\t\tIPADataSerializer<uint',
                    str(t_1(l_1_field)),
                    '_t>::serialize(static_cast<uint',
                    str(t_1(l_1_field)),
                    '_t>(data.',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    '));',
                ))
            elif t_6(l_1_field):
                pass
                t_18.extend((
                    '\n\t\t\tIPADataSerializer<uint',
                    str(t_1(l_1_field)),
                    '_t>::serialize(data.',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    ');',
                ))
            t_18.extend((
                '\n\t\tretData.insert(retData.end(), ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                '.begin(), ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                '.end());',
            ))
        elif t_8(l_1_field):
            pass
            t_18.extend((
                '\n\t\tstd::vector<uint8_t> ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                ';\n\t\tstd::vector<SharedFD> ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                'Fds;\n\t\tstd::tie(',
                str(environment.getattr(l_1_field, 'mojom_name')),
                ', ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                'Fds) =\n\t\t\tIPADataSerializer<',
                str(t_14(l_1_field)),
                '>::serialize(data.',
                str(environment.getattr(l_1_field, 'mojom_name')),
                ');\n\t\tretData.insert(retData.end(), ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                '.begin(), ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                '.end());\n\t\tretFds.insert(retFds.end(), ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                'Fds.begin(), ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                'Fds.end());',
            ))
        elif t_5(l_1_field):
            pass
            t_18.extend((
                '\n\t\tif (data.',
                str(environment.getattr(l_1_field, 'mojom_name')),
                '.size() > 0) {\n\t\t\tstd::vector<uint8_t> ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                ';\n\t\t\tstd::tie(',
                str(environment.getattr(l_1_field, 'mojom_name')),
                ', std::ignore) =\n\t\t\t\tIPADataSerializer<',
                str(t_14(l_1_field)),
                '>::serialize(data.',
                str(environment.getattr(l_1_field, 'mojom_name')),
                ', cs);\n\t\t\tappendPOD<uint32_t>(retData, ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                '.size());\n\t\t\tretData.insert(retData.end(), ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                '.begin(), ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                '.end());\n\t\t} else {\n\t\t\tappendPOD<uint32_t>(retData, 0);\n\t\t}',
            ))
        elif (((t_11(l_1_field) or t_4(l_1_field)) or t_10(l_1_field)) or t_13(l_1_field)):
            pass
            t_18.extend((
                '\n\t\tstd::vector<uint8_t> ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                ';',
            ))
            if t_2(l_1_field):
                pass
                t_18.extend((
                    '\n\t\tstd::vector<SharedFD> ',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    'Fds;\n\t\tstd::tie(',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    ', ',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    'Fds) =',
                ))
            else:
                pass
                t_18.extend((
                    '\n\t\tstd::tie(',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    ', std::ignore) =',
                ))
            if (t_4(l_1_field) or t_10(l_1_field)):
                pass
                t_18.extend((
                    '\n\t\t\tIPADataSerializer<',
                    str(t_14(l_1_field)),
                    '>::serialize(data.',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    ', cs);',
                ))
            elif t_13(l_1_field):
                pass
                t_18.extend((
                    '\n\t\t\tIPADataSerializer<',
                    str(t_14(l_1_field)),
                    '>::serialize(data.',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    ');',
                ))
            else:
                pass
                t_18.extend((
                    '\n\t\t\tIPADataSerializer<',
                    str(t_15(l_1_field)),
                    '>::serialize(data.',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    ', cs);',
                ))
            t_18.extend((
                '\n\t\tappendPOD<uint32_t>(retData, ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                '.size());',
            ))
            if t_2(l_1_field):
                pass
                t_18.extend((
                    '\n\t\tappendPOD<uint32_t>(retData, ',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    'Fds.size());',
                ))
            t_18.extend((
                '\n\t\tretData.insert(retData.end(), ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                '.begin(), ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                '.end());',
            ))
            if t_2(l_1_field):
                pass
                t_18.extend((
                    '\n\t\tretFds.insert(retFds.end(), ',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    'Fds.begin(), ',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    'Fds.end());',
                ))
        else:
            pass
            t_18.extend((
                '\n\t\t/* Unknown serialization for ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                '. */',
            ))
        return concat(t_18)
    context.exported_vars.add('serializer_field')
    context.vars['serializer_field'] = l_0_serializer_field = Macro(environment, macro, 'serializer_field', ('field', 'loop'), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n\n'
    def macro(l_1_field, l_1_loop):
        t_19 = []
        l_1_field_size = resolve('field_size')
        if l_1_field is missing:
            l_1_field = undefined("parameter 'field' was not provided", name='field')
        if l_1_loop is missing:
            l_1_loop = undefined("parameter 'loop' was not provided", name='loop')
        pass
        t_19.append(
            '\n',
        )
        if (t_12(l_1_field) or t_6(l_1_field)):
            pass
            l_1_field_size = t_3((t_3(t_1(l_1_field)) / 8))
            t_19.append(
                str(context.call((undefined(name='check_data_size') if l_0_check_data_size is missing else l_0_check_data_size), (undefined(name='field_size') if l_1_field_size is missing else l_1_field_size), 'dataSize', environment.getattr(l_1_field, 'mojom_name'), 'data')),
            )
            if t_12(l_1_field):
                pass
                t_19.extend((
                    '\n\t\tret.',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    ' = IPADataSerializer<',
                    str(t_14(l_1_field)),
                    '>::deserialize(m, m + ',
                    str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                    ');',
                ))
            elif t_9(l_1_field):
                pass
                t_19.extend((
                    '\n\t\tret.',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    ' = IPADataSerializer<',
                    str(t_15(l_1_field)),
                    '>::deserialize(m, m + ',
                    str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                    ');',
                ))
            else:
                pass
                t_19.extend((
                    '\n\t\tret.',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    ' = static_cast<',
                    str(t_15(l_1_field)),
                    '>(IPADataSerializer<uint',
                    str(t_1(l_1_field)),
                    '_t>::deserialize(m, m + ',
                    str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                    '));',
                ))
            if (not environment.getattr(l_1_loop, 'last')):
                pass
                t_19.extend((
                    '\n\t\tm += ',
                    str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                    ';\n\t\tdataSize -= ',
                    str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                    ';',
                ))
            t_19.append(
                '\n',
            )
        elif t_8(l_1_field):
            pass
            l_1_field_size = 4
            t_19.extend((
                str(context.call((undefined(name='check_data_size') if l_0_check_data_size is missing else l_0_check_data_size), (undefined(name='field_size') if l_1_field_size is missing else l_1_field_size), 'dataSize', environment.getattr(l_1_field, 'mojom_name'), 'data')),
                '\n\t\tret.',
                str(environment.getattr(l_1_field, 'mojom_name')),
                ' = IPADataSerializer<',
                str(t_14(l_1_field)),
                '>::deserialize(m, m + ',
                str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                ', n, n + 1, cs);',
            ))
            if (not environment.getattr(l_1_loop, 'last')):
                pass
                t_19.extend((
                    '\n\t\tm += ',
                    str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                    ';\n\t\tdataSize -= ',
                    str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                    ';\n\t\tn += ret.',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    '.isValid() ? 1 : 0;\n\t\tfdsSize -= ret.',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    '.isValid() ? 1 : 0;',
                ))
            t_19.append(
                '\n',
            )
        elif t_5(l_1_field):
            pass
            l_1_field_size = 4
            t_19.extend((
                str(context.call((undefined(name='check_data_size') if l_0_check_data_size is missing else l_0_check_data_size), (undefined(name='field_size') if l_1_field_size is missing else l_1_field_size), 'dataSize', (environment.getattr(l_1_field, 'mojom_name') + 'Size'), 'data')),
                '\n\t\tconst size_t ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                'Size = readPOD<uint32_t>(m, 0, dataEnd);\n\t\tm += ',
                str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                ';\n\t\tdataSize -= ',
                str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                ';',
            ))
            l_1_field_size = (environment.getattr(l_1_field, 'mojom_name') + 'Size')
            t_19.extend((
                str(context.call((undefined(name='check_data_size') if l_0_check_data_size is missing else l_0_check_data_size), (undefined(name='field_size') if l_1_field_size is missing else l_1_field_size), 'dataSize', environment.getattr(l_1_field, 'mojom_name'), 'data')),
                '\n\t\tif (',
                str(environment.getattr(l_1_field, 'mojom_name')),
                'Size > 0)\n\t\t\tret.',
                str(environment.getattr(l_1_field, 'mojom_name')),
                ' =\n\t\t\t\tIPADataSerializer<',
                str(t_14(l_1_field)),
                '>::deserialize(m, m + ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                'Size, cs);',
            ))
            if (not environment.getattr(l_1_loop, 'last')):
                pass
                t_19.extend((
                    '\n\t\tm += ',
                    str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                    ';\n\t\tdataSize -= ',
                    str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                    ';',
                ))
            t_19.append(
                '\n',
            )
        elif (((t_11(l_1_field) or t_4(l_1_field)) or t_10(l_1_field)) or t_13(l_1_field)):
            pass
            l_1_field_size = 4
            t_19.extend((
                str(context.call((undefined(name='check_data_size') if l_0_check_data_size is missing else l_0_check_data_size), (undefined(name='field_size') if l_1_field_size is missing else l_1_field_size), 'dataSize', (environment.getattr(l_1_field, 'mojom_name') + 'Size'), 'data')),
                '\n\t\tconst size_t ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                'Size = readPOD<uint32_t>(m, 0, dataEnd);\n\t\tm += ',
                str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                ';\n\t\tdataSize -= ',
                str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                ';',
            ))
            if t_2(l_1_field):
                pass
                l_1_field_size = 4
                t_19.extend((
                    str(context.call((undefined(name='check_data_size') if l_0_check_data_size is missing else l_0_check_data_size), (undefined(name='field_size') if l_1_field_size is missing else l_1_field_size), 'dataSize', (environment.getattr(l_1_field, 'mojom_name') + 'FdsSize'), 'data')),
                    '\n\t\tconst size_t ',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    'FdsSize = readPOD<uint32_t>(m, 0, dataEnd);\n\t\tm += ',
                    str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                    ';\n\t\tdataSize -= ',
                    str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                    ';',
                    str(context.call((undefined(name='check_data_size') if l_0_check_data_size is missing else l_0_check_data_size), (environment.getattr(l_1_field, 'mojom_name') + 'FdsSize'), 'fdsSize', environment.getattr(l_1_field, 'mojom_name'), 'fds')),
                ))
            l_1_field_size = (environment.getattr(l_1_field, 'mojom_name') + 'Size')
            t_19.extend((
                str(context.call((undefined(name='check_data_size') if l_0_check_data_size is missing else l_0_check_data_size), (undefined(name='field_size') if l_1_field_size is missing else l_1_field_size), 'dataSize', environment.getattr(l_1_field, 'mojom_name'), 'data')),
                '\n\t\tret.',
                str(environment.getattr(l_1_field, 'mojom_name')),
                ' =',
            ))
            if t_13(l_1_field):
                pass
                t_19.extend((
                    '\n\t\t\tIPADataSerializer<',
                    str(t_14(l_1_field)),
                    '>::deserialize(m, m + ',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    'Size);',
                ))
            elif (t_2(l_1_field) and (t_4(l_1_field) or t_10(l_1_field))):
                pass
                t_19.extend((
                    '\n\t\t\tIPADataSerializer<',
                    str(t_14(l_1_field)),
                    '>::deserialize(m, m + ',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    'Size, n, n + ',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    'FdsSize, cs);',
                ))
            elif (t_2(l_1_field) and (not (t_4(l_1_field) or t_10(l_1_field)))):
                pass
                t_19.extend((
                    '\n\t\t\tIPADataSerializer<',
                    str(t_15(l_1_field)),
                    '>::deserialize(m, m + ',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    'Size, n, n + ',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    'FdsSize, cs);',
                ))
            elif ((not t_2(l_1_field)) and (t_4(l_1_field) or t_10(l_1_field))):
                pass
                t_19.extend((
                    '\n\t\t\tIPADataSerializer<',
                    str(t_14(l_1_field)),
                    '>::deserialize(m, m + ',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    'Size, cs);',
                ))
            else:
                pass
                t_19.extend((
                    '\n\t\t\tIPADataSerializer<',
                    str(t_15(l_1_field)),
                    '>::deserialize(m, m + ',
                    str(environment.getattr(l_1_field, 'mojom_name')),
                    'Size, cs);',
                ))
            if (not environment.getattr(l_1_loop, 'last')):
                pass
                t_19.extend((
                    '\n\t\tm += ',
                    str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                    ';\n\t\tdataSize -= ',
                    str((undefined(name='field_size') if l_1_field_size is missing else l_1_field_size)),
                    ';',
                ))
                if t_2(l_1_field):
                    pass
                    t_19.extend((
                        '\n\t\tn += ',
                        str(environment.getattr(l_1_field, 'mojom_name')),
                        'FdsSize;\n\t\tfdsSize -= ',
                        str(environment.getattr(l_1_field, 'mojom_name')),
                        'FdsSize;',
                    ))
            t_19.append(
                '\n',
            )
        else:
            pass
            t_19.extend((
                '\n\t\t/* Unknown deserialization for ',
                str(environment.getattr(l_1_field, 'mojom_name')),
                '. */',
            ))
        return concat(t_19)
    context.exported_vars.add('deserializer_field')
    context.vars['deserializer_field'] = l_0_deserializer_field = Macro(environment, macro, 'deserializer_field', ('field', 'loop'), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n\n'
    def macro(l_1_struct):
        t_20 = []
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        pass
        t_20.extend((
            '\n\tstatic std::tuple<std::vector<uint8_t>, std::vector<SharedFD>>\n\tserialize(const ',
            str(t_15(l_1_struct)),
            ' &data,',
        ))
        if t_16(l_1_struct):
            pass
            t_20.append(
                '\n\t\t  ControlSerializer *cs)',
            )
        else:
            pass
            t_20.append(
                '\n\t\t  [[maybe_unused]] ControlSerializer *cs = nullptr)',
            )
        t_20.append(
            '\n\t{\n\t\tstd::vector<uint8_t> retData;',
        )
        if t_2(l_1_struct):
            pass
            t_20.append(
                '\n\t\tstd::vector<SharedFD> retFds;',
            )
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_struct, 'fields'), undefined):
            _loop_vars = {}
            pass
            t_20.extend((
                '\n',
                str(context.call((undefined(name='serializer_field') if l_0_serializer_field is missing else l_0_serializer_field), l_2_field, l_2_loop, _loop_vars=_loop_vars)),
            ))
        l_2_loop = l_2_field = missing
        t_20.append(
            '\n',
        )
        if t_2(l_1_struct):
            pass
            t_20.append(
                '\n\t\treturn {retData, retFds};',
            )
        else:
            pass
            t_20.append(
                '\n\t\treturn {retData, {}};',
            )
        t_20.append(
            '\n\t}',
        )
        return concat(t_20)
    context.exported_vars.add('serializer')
    context.vars['serializer'] = l_0_serializer = Macro(environment, macro, 'serializer', ('struct',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n\n'
    def macro(l_1_struct):
        t_21 = []
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        pass
        t_21.extend((
            '\n\tstatic ',
            str(t_15(l_1_struct)),
            '\n\tdeserialize(std::vector<uint8_t> &data,\n\t\t    std::vector<SharedFD> &fds,',
        ))
        if t_16(l_1_struct):
            pass
            t_21.append(
                '\n\t\t    ControlSerializer *cs)',
            )
        else:
            pass
            t_21.append(
                '\n\t\t    ControlSerializer *cs = nullptr)',
            )
        t_21.extend((
            '\n\t{\n\t\treturn IPADataSerializer<',
            str(t_15(l_1_struct)),
            '>::deserialize(data.cbegin(), data.cend(), fds.cbegin(), fds.cend(), cs);\n\t}\n\n\n\tstatic ',
            str(t_15(l_1_struct)),
            '\n\tdeserialize(std::vector<uint8_t>::const_iterator dataBegin,\n\t\t    std::vector<uint8_t>::const_iterator dataEnd,\n\t\t    std::vector<SharedFD>::const_iterator fdsBegin,\n\t\t    std::vector<SharedFD>::const_iterator fdsEnd,',
        ))
        if t_16(l_1_struct):
            pass
            t_21.append(
                '\n\t\t    ControlSerializer *cs)',
            )
        else:
            pass
            t_21.append(
                '\n\t\t    [[maybe_unused]] ControlSerializer *cs = nullptr)',
            )
        t_21.extend((
            '\n\t{\n\t\t',
            str(t_15(l_1_struct)),
            ' ret;\n\t\tstd::vector<uint8_t>::const_iterator m = dataBegin;\n\t\tstd::vector<SharedFD>::const_iterator n = fdsBegin;\n\n\t\tsize_t dataSize = std::distance(dataBegin, dataEnd);\n\t\t[[maybe_unused]] size_t fdsSize = std::distance(fdsBegin, fdsEnd);',
        ))
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_struct, 'fields'), undefined):
            _loop_vars = {}
            pass
            t_21.append(
                str(context.call((undefined(name='deserializer_field') if l_0_deserializer_field is missing else l_0_deserializer_field), l_2_field, l_2_loop, _loop_vars=_loop_vars)),
            )
        l_2_loop = l_2_field = missing
        t_21.append(
            '\n\t\treturn ret;\n\t}',
        )
        return concat(t_21)
    context.exported_vars.add('deserializer_fd')
    context.vars['deserializer_fd'] = l_0_deserializer_fd = Macro(environment, macro, 'deserializer_fd', ('struct',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n'
    def macro(l_1_struct):
        t_22 = []
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        pass
        t_22.extend((
            '\n\tstatic ',
            str(t_15(l_1_struct)),
            '\n\tdeserialize(std::vector<uint8_t> &data,\n\t\t    [[maybe_unused]] std::vector<SharedFD> &fds,\n\t\t    ControlSerializer *cs = nullptr)\n\t{\n\t\treturn IPADataSerializer<',
            str(t_15(l_1_struct)),
            '>::deserialize(data.cbegin(), data.cend(), cs);\n\t}\n\n\tstatic ',
            str(t_15(l_1_struct)),
            '\n\tdeserialize(std::vector<uint8_t>::const_iterator dataBegin,\n\t\t    std::vector<uint8_t>::const_iterator dataEnd,\n\t\t    [[maybe_unused]] std::vector<SharedFD>::const_iterator fdsBegin,\n\t\t    [[maybe_unused]] std::vector<SharedFD>::const_iterator fdsEnd,\n\t\t    ControlSerializer *cs = nullptr)\n\t{\n\t\treturn IPADataSerializer<',
            str(t_15(l_1_struct)),
            '>::deserialize(dataBegin, dataEnd, cs);\n\t}',
        ))
        return concat(t_22)
    context.exported_vars.add('deserializer_fd_simple')
    context.vars['deserializer_fd_simple'] = l_0_deserializer_fd_simple = Macro(environment, macro, 'deserializer_fd_simple', ('struct',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n\n'
    def macro(l_1_struct):
        t_23 = []
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        pass
        t_23.extend((
            '\n\tstatic ',
            str(t_15(l_1_struct)),
            '\n\tdeserialize(std::vector<uint8_t> &data,',
        ))
        if t_16(l_1_struct):
            pass
            t_23.append(
                '\n\t\t    ControlSerializer *cs)',
            )
        else:
            pass
            t_23.append(
                '\n\t\t    ControlSerializer *cs = nullptr)',
            )
        t_23.extend((
            '\n\t{\n\t\treturn IPADataSerializer<',
            str(t_15(l_1_struct)),
            '>::deserialize(data.cbegin(), data.cend(), cs);\n\t}\n\n\n\tstatic ',
            str(t_15(l_1_struct)),
            '\n\tdeserialize(std::vector<uint8_t>::const_iterator dataBegin,\n\t\t    std::vector<uint8_t>::const_iterator dataEnd,',
        ))
        if t_16(l_1_struct):
            pass
            t_23.append(
                '\n\t\t    ControlSerializer *cs)',
            )
        else:
            pass
            t_23.append(
                '\n\t\t    [[maybe_unused]] ControlSerializer *cs = nullptr)',
            )
        t_23.extend((
            '\n\t{\n\t\t',
            str(t_15(l_1_struct)),
            ' ret;\n\t\tstd::vector<uint8_t>::const_iterator m = dataBegin;\n\n\t\tsize_t dataSize = std::distance(dataBegin, dataEnd);',
        ))
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_struct, 'fields'), undefined):
            _loop_vars = {}
            pass
            t_23.append(
                str(context.call((undefined(name='deserializer_field') if l_0_deserializer_field is missing else l_0_deserializer_field), l_2_field, l_2_loop, _loop_vars=_loop_vars)),
            )
        l_2_loop = l_2_field = missing
        t_23.append(
            '\n\t\treturn ret;\n\t}',
        )
        return concat(t_23)
    context.exported_vars.add('deserializer_no_fd')
    context.vars['deserializer_no_fd'] = l_0_deserializer_no_fd = Macro(environment, macro, 'deserializer_no_fd', ('struct',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n'
    def macro(l_1_struct):
        t_24 = []
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        pass
        if t_2(l_1_struct):
            pass
            t_24.extend((
                '\n',
                str(context.call((undefined(name='deserializer_fd') if l_0_deserializer_fd is missing else l_0_deserializer_fd), l_1_struct)),
            ))
        else:
            pass
            t_24.extend((
                '\n',
                str(context.call((undefined(name='deserializer_no_fd') if l_0_deserializer_no_fd is missing else l_0_deserializer_no_fd), l_1_struct)),
                '\n',
                str(context.call((undefined(name='deserializer_fd_simple') if l_0_deserializer_fd_simple is missing else l_0_deserializer_fd_simple), l_1_struct)),
            ))
        return concat(t_24)
    context.exported_vars.add('deserializer')
    context.vars['deserializer'] = l_0_deserializer = Macro(environment, macro, 'deserializer', ('struct',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '11=108&12=121&14=125&15=127&16=129&31=138&32=145&33=149&34=151&35=154&36=158&37=163&38=167&39=172&40=176&41=183&42=187&44=194&45=199&46=203&47=205&48=207&49=211&50=215&51=219&52=224&53=228&54=230&55=232&56=234&57=238&58=240&62=245&63=249&64=252&65=256&66=258&68=267&70=270&71=274&72=279&73=283&75=292&77=299&78=302&79=306&81=311&82=316&83=320&86=329&97=336&98=347&99=349&100=351&101=353&102=357&103=364&104=368&106=379&108=388&109=392&110=394&112=400&113=402&114=404&115=406&116=413&117=417&118=419&119=421&120=423&122=429&123=431&124=433&125=435&126=437&127=439&128=442&129=444&130=446&131=448&132=450&133=455&134=459&135=461&137=467&138=469&139=471&140=473&141=475&142=477&143=480&144=482&145=484&146=486&147=488&148=490&149=492&151=494&152=496&153=498&154=501&155=505&156=510&157=514&158=521&159=525&160=532&161=536&163=545&165=550&166=554&167=556&168=559&169=563&170=565&174=575&185=582&187=589&188=592&195=605&198=611&199=616&201=622&216=639&217=646&220=649&226=661&230=663&235=666&241=678&247=682&248=686&261=696&262=703&267=705&270=707&277=709&288=716&289=723&291=726&297=738&301=740&304=743&310=755&314=759&315=763&326=773&327=778&328=782&330=788&331=790'