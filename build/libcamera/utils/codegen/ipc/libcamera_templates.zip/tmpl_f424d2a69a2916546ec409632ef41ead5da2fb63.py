from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module_ipa_proxy.cpp.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module_name = resolve('module_name')
    l_0_has_namespace = resolve('has_namespace')
    l_0_namespace = resolve('namespace')
    l_0_proxy_name = resolve('proxy_name')
    l_0_interface_name = resolve('interface_name')
    l_0_interface_event = resolve('interface_event')
    l_0_cmd_enum_name = resolve('cmd_enum_name')
    l_0_cmd_event_enum_name = resolve('cmd_event_enum_name')
    l_0_interface_main = resolve('interface_main')
    l_0_proxy_funcs = missing
    try:
        t_1 = environment.filters['byte_width']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'byte_width' found.")
    try:
        t_2 = environment.filters['cap']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cap' found.")
    try:
        t_3 = environment.filters['int']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'int' found.")
    try:
        t_4 = environment.filters['is_async']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_async' found.")
    try:
        t_5 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_6 = environment.filters['method_param_inputs']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'method_param_inputs' found.")
    try:
        t_7 = environment.filters['method_param_names']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'method_param_names' found.")
    try:
        t_8 = environment.filters['method_param_outputs']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'method_param_outputs' found.")
    try:
        t_9 = environment.filters['method_return_value']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'method_return_value' found.")
    try:
        t_10 = environment.filters['params_comma_sep']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'params_comma_sep' found.")
    try:
        t_11 = environment.filters['reverse']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'reverse' found.")
    pass
    l_0_proxy_funcs = context.vars['proxy_funcs'] = environment.get_template('proxy_functions.tmpl', 'module_ipa_proxy.cpp.tmpl')._get_default_module(context)
    context.exported_vars.discard('proxy_funcs')
    yield '/* SPDX-License-Identifier: LGPL-2.1-or-later */\n/*\n * Copyright (C) 2020, Google Inc.\n *\n * Image Processing Algorithm proxy for '
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '\n *\n * This file is auto-generated. Do not edit.\n */\n\n#include <libcamera/ipa/'
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '_ipa_proxy.h>\n\n#include <memory>\n#include <string>\n#include <vector>\n\n#include <libcamera/ipa/ipa_module_info.h>\n#include <libcamera/ipa/'
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '_ipa_interface.h>\n#include <libcamera/ipa/'
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '_ipa_serializer.h>\n\n#include <libcamera/base/log.h>\n#include <libcamera/base/thread.h>\n\n#include "libcamera/internal/control_serializer.h"\n#include "libcamera/internal/ipa_data_serializer.h"\n#include "libcamera/internal/ipa_module.h"\n#include "libcamera/internal/ipa_proxy.h"\n#include "libcamera/internal/ipc_pipe.h"\n#include "libcamera/internal/ipc_pipe_unixsocket.h"\n#include "libcamera/internal/ipc_unixsocket.h"\n#include "libcamera/internal/process.h"\n\nnamespace libcamera {\n\nLOG_DECLARE_CATEGORY(IPAProxy)'
    if (undefined(name='has_namespace') if l_0_has_namespace is missing else l_0_has_namespace):
        pass
        yield '\n'
        for l_1_ns in (undefined(name='namespace') if l_0_namespace is missing else l_0_namespace):
            _loop_vars = {}
            pass
            yield '\nnamespace '
            yield str(l_1_ns)
            yield ' {\n'
        l_1_ns = missing
    yield '\n\n'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield '::'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield '(IPAModule *ipam, bool isolate)\n\t: IPAProxy(ipam), isolate_(isolate),\n\t  controlSerializer_(ControlSerializer::Role::Proxy), seq_(0)\n{\n\tLOG(IPAProxy, Debug)\n\t\t<< "initializing '
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield ' proxy: loading IPA from "\n\t\t<< ipam->path();\n\n\tif (isolate_) {\n\t\tconst std::string proxyWorkerPath = resolvePath("'
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '_ipa_proxy");\n\t\tif (proxyWorkerPath.empty()) {\n\t\t\tLOG(IPAProxy, Error)\n\t\t\t\t<< "Failed to get proxy worker path";\n\t\t\treturn;\n\t\t}\n\n\t\tauto ipc = std::make_unique<IPCPipeUnixSocket>(ipam->path().c_str(),\n\t\t\t\t\t\t\t       proxyWorkerPath.c_str());\n\t\tif (!ipc->isConnected()) {\n\t\t\tLOG(IPAProxy, Error) << "Failed to create IPCPipe";\n\t\t\treturn;\n\t\t}\n\n\t\tipc->recv.connect(this, &'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield '::recvMessage);\n\n\t\tipc_ = std::move(ipc);\n\t\tvalid_ = true;\n\t\treturn;\n\t}\n\n\tif (!ipam->load())\n\t\treturn;\n\n\tIPAInterface *ipai = ipam->createInterface();\n\tif (!ipai) {\n\t\tLOG(IPAProxy, Error)\n\t\t\t<< "Failed to create IPA context for " << ipam->path();\n\t\treturn;\n\t}\n\n\tipa_ = std::unique_ptr<'
    yield str((undefined(name='interface_name') if l_0_interface_name is missing else l_0_interface_name))
    yield '>(static_cast<'
    yield str((undefined(name='interface_name') if l_0_interface_name is missing else l_0_interface_name))
    yield ' *>(ipai));\n\tproxy_.setIPA(ipa_.get());\n\n'
    for l_1_method in environment.getattr((undefined(name='interface_event') if l_0_interface_event is missing else l_0_interface_event), 'methods'):
        _loop_vars = {}
        pass
        yield '\n\tipa_->'
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield '.connect(this, &'
        yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
        yield '::'
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield 'Thread);'
    l_1_method = missing
    yield '\n\n\tvalid_ = true;\n}\n\n'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield '::~'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield '()\n{\n\tif (ipc_) {\n\t\tIPCMessage::Header header =\n\t\t\t{ static_cast<uint32_t>('
    yield str((undefined(name='cmd_enum_name') if l_0_cmd_enum_name is missing else l_0_cmd_enum_name))
    yield '::Exit), seq_++ };\n\t\tIPCMessage msg(header);\n\t\tipc_->sendAsync(msg);\n\t}\n}\n\n'
    if (t_5(environment.getattr((undefined(name='interface_event') if l_0_interface_event is missing else l_0_interface_event), 'methods')) > 0):
        pass
        yield '\nvoid '
        yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
        yield '::recvMessage(const IPCMessage &data)\n{\n\tsize_t dataSize = data.data().size();\n\t'
        yield str((undefined(name='cmd_event_enum_name') if l_0_cmd_event_enum_name is missing else l_0_cmd_event_enum_name))
        yield ' _cmd = static_cast<'
        yield str((undefined(name='cmd_event_enum_name') if l_0_cmd_event_enum_name is missing else l_0_cmd_event_enum_name))
        yield '>(data.header().cmd);\n\n\tswitch (_cmd) {'
        for l_1_method in environment.getattr((undefined(name='interface_event') if l_0_interface_event is missing else l_0_interface_event), 'methods'):
            _loop_vars = {}
            pass
            yield '\n\tcase '
            yield str((undefined(name='cmd_event_enum_name') if l_0_cmd_event_enum_name is missing else l_0_cmd_event_enum_name))
            yield '::'
            yield str(t_2(environment.getattr(l_1_method, 'mojom_name')))
            yield ': {\n\t\t'
            yield str(environment.getattr(l_1_method, 'mojom_name'))
            yield 'IPC(data.data().cbegin(), dataSize, data.fds());\n\t\tbreak;\n\t}'
        l_1_method = missing
        yield '\n\tdefault:\n\t\tLOG(IPAProxy, Error) << "Unknown command " << static_cast<uint32_t>(_cmd);\n\t}\n}'
    yield '\n\n'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface_main') if l_0_interface_main is missing else l_0_interface_main), 'methods'), undefined):
        l_1_has_output = l_1_cmd = missing
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'func_sig'), (undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name), l_1_method, _loop_vars=_loop_vars))
        yield '\n{\n\tif (isolate_)\n\t\treturn '
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield 'IPC('
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(t_7(l_1_method), undefined):
            _loop_vars = {}
            pass
            yield str(l_2_param)
            yield str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 133 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
        l_2_loop = l_2_param = missing
        yield ');\n\telse\n\t\treturn '
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield 'Thread('
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(t_7(l_1_method), undefined):
            _loop_vars = {}
            pass
            yield str(l_2_param)
            yield str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 139 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
        l_2_loop = l_2_param = missing
        yield ');\n}\n\n'
        yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'func_sig'), (undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name), l_1_method, 'Thread', _loop_vars=_loop_vars))
        yield '\n{'
        if (environment.getattr(l_1_method, 'mojom_name') == 'stop'):
            pass
            yield '\n\t'
            yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'stop_thread_body'), _loop_vars=_loop_vars))
        elif (environment.getattr(l_1_method, 'mojom_name') == 'init'):
            pass
            yield '\n\t'
            yield str(((t_9(l_1_method) + ' _ret = ') if (t_9(l_1_method) != 'void') else cond_expr_undefined("the inline if-expression on line 149 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
            yield 'ipa_->'
            yield str(environment.getattr(l_1_method, 'mojom_name'))
            yield '('
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(t_7(l_1_method), undefined):
                _loop_vars = {}
                pass
                yield str(l_2_param)
                yield str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 152 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
            l_2_loop = l_2_param = missing
            yield ');\n\n\tproxy_.moveToThread(&thread_);\n\n\treturn '
            yield str(('_ret' if (t_9(l_1_method) != 'void') else cond_expr_undefined("the inline if-expression on line 158 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
            yield ';'
        elif (environment.getattr(l_1_method, 'mojom_name') == 'start'):
            pass
            yield '\n\tstate_ = ProxyRunning;\n\tthread_.start();\n\n\treturn proxy_.invokeMethod(&ThreadProxy::start, ConnectionTypeBlocking'
            yield str((', ' if t_7(l_1_method) else cond_expr_undefined("the inline if-expression on line 164 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(t_7(l_1_method), undefined):
                _loop_vars = {}
                pass
                yield str(l_2_param)
                yield str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 166 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
            l_2_loop = l_2_param = missing
            yield ');'
        elif (not t_4(l_1_method)):
            pass
            yield '\n\treturn ipa_->'
            yield str(environment.getattr(l_1_method, 'mojom_name'))
            yield '('
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(t_7(l_1_method), undefined):
                _loop_vars = {}
                pass
                yield str(l_2_param)
                yield str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 172 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
            l_2_loop = l_2_param = missing
            yield ');\n'
        elif t_4(l_1_method):
            pass
            yield '\n\tASSERT(state_ == ProxyRunning);\n\tproxy_.invokeMethod(&ThreadProxy::'
            yield str(environment.getattr(l_1_method, 'mojom_name'))
            yield ', ConnectionTypeQueued'
            for l_2_param in t_7(l_1_method):
                _loop_vars = {}
                pass
                yield ', '
                yield str(l_2_param)
            l_2_param = missing
            yield ');'
        yield '\n}\n\n'
        yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'func_sig'), (undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name), l_1_method, 'IPC', _loop_vars=_loop_vars))
        yield '\n{'
        if (environment.getattr(l_1_method, 'mojom_name') == 'configure'):
            pass
            yield '\n\tcontrolSerializer_.reset();'
        l_1_has_output = (True if ((t_5(t_8(l_1_method)) > 0) or (t_9(l_1_method) != 'void')) else cond_expr_undefined("the inline if-expression on line 190 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined."))
        _loop_vars['has_output'] = l_1_has_output
        l_1_cmd = (((undefined(name='cmd_enum_name') if l_0_cmd_enum_name is missing else l_0_cmd_enum_name) + '::') + t_2(environment.getattr(l_1_method, 'mojom_name')))
        _loop_vars['cmd'] = l_1_cmd
        yield '\n\tIPCMessage::Header _header = { static_cast<uint32_t>('
        yield str((undefined(name='cmd') if l_1_cmd is missing else l_1_cmd))
        yield '), seq_++ };\n\tIPCMessage _ipcInputBuf(_header);'
        if (undefined(name='has_output') if l_1_has_output is missing else l_1_has_output):
            pass
            yield '\n\tIPCMessage _ipcOutputBuf;'
        yield '\n\n'
        yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'serialize_call'), t_6(l_1_method), '_ipcInputBuf.data()', '_ipcInputBuf.fds()', _loop_vars=_loop_vars))
        yield '\n\n'
        if t_4(l_1_method):
            pass
            yield '\n\tint _ret = ipc_->sendAsync(_ipcInputBuf);'
        else:
            pass
            yield '\n\tint _ret = ipc_->sendSync(_ipcInputBuf'
            yield str((', &_ipcOutputBuf' if (undefined(name='has_output') if l_1_has_output is missing else l_1_has_output) else cond_expr_undefined("the inline if-expression on line 204 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
            yield ');'
        yield '\n\tif (_ret < 0) {\n\t\tLOG(IPAProxy, Error) << "Failed to call '
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield ': " << _ret;'
        if (t_9(l_1_method) != 'void'):
            pass
            yield '\n\t\treturn static_cast<'
            yield str(t_9(l_1_method))
            yield '>(_ret);'
        else:
            pass
            yield '\n\t\treturn;'
        yield '\n\t}\n'
        if (t_9(l_1_method) != 'void'):
            pass
            yield '\n\t'
            yield str(t_9(l_1_method))
            yield ' _retValue = IPADataSerializer<'
            yield str(t_9(l_1_method))
            yield '>::deserialize(_ipcOutputBuf.data(), 0);\n\n'
            yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'deserialize_call'), t_8(l_1_method), '_ipcOutputBuf.data()', '_ipcOutputBuf.fds()', init_offset=t_3(t_1(t_9(l_1_method))), _loop_vars=_loop_vars))
            yield '\n\n\treturn _retValue;\n\n'
        elif (t_5(t_8(l_1_method)) > 0):
            pass
            yield '\n'
            yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'deserialize_call'), t_8(l_1_method), '_ipcOutputBuf.data()', '_ipcOutputBuf.fds()', _loop_vars=_loop_vars))
            yield '\n'
        yield '}\n\n'
    l_1_loop = l_1_method = l_1_has_output = l_1_cmd = missing
    yield '\n\n'
    for l_1_method in environment.getattr((undefined(name='interface_event') if l_0_interface_event is missing else l_0_interface_event), 'methods'):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'func_sig'), (undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name), l_1_method, 'Thread', _loop_vars=_loop_vars))
        yield '\n{\n\tASSERT(state_ != ProxyStopped);\n\t'
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield '.emit('
        yield str(t_10(environment.getattr(l_1_method, 'parameters')))
        yield ');\n}\n\nvoid '
        yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
        yield '::'
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield 'IPC(\n\t[[maybe_unused]] std::vector<uint8_t>::const_iterator data,\n\t[[maybe_unused]] size_t dataSize,\n\t[[maybe_unused]] const std::vector<SharedFD> &fds)\n{\n'
        yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'deserialize_call'), environment.getattr(l_1_method, 'parameters'), 'data', 'fds', False, True, True, 'dataSize', _loop_vars=_loop_vars))
        yield '\n\t'
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield '.emit('
        yield str(t_10(environment.getattr(l_1_method, 'parameters')))
        yield ');\n}\n'
    l_1_method = missing
    if (undefined(name='has_namespace') if l_0_has_namespace is missing else l_0_has_namespace):
        pass
        yield '\n'
        for l_1_ns in t_11((undefined(name='namespace') if l_0_namespace is missing else l_0_namespace)):
            _loop_vars = {}
            pass
            yield '\n} /* namespace '
            yield str(l_1_ns)
            yield ' */\n'
        l_1_ns = missing
    yield '\n} /* namespace libcamera */'

blocks = {}
debug_info = '5=87&11=90&16=92&23=94&24=96&42=98&43=101&44=105&48=109&53=113&57=115&71=117&88=119&91=123&92=127&98=135&102=139&108=141&109=144&112=146&115=150&116=154&117=158&127=164&128=169&131=171&132=174&133=177&137=181&138=184&139=187&144=191&146=193&147=196&148=197&149=200&150=202&151=205&152=208&158=212&159=214&164=217&165=219&166=222&169=226&170=229&171=232&172=235&175=239&177=242&178=244&179=248&185=252&187=254&190=257&191=259&192=262&194=264&198=268&200=270&204=276&208=279&209=281&210=284&215=290&216=293&218=297&222=299&223=302&229=307&230=311&233=313&236=317&241=321&242=323&246=328&247=331&248=335'